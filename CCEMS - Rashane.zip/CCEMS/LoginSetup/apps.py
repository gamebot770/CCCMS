from django.apps import AppConfig

class LoginSetupConfig(AppConfig):
    name = 'LoginSetup'
