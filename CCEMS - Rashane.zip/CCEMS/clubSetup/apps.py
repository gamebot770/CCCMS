from django.apps import AppConfig


class ClubsetupConfig(AppConfig):
    name = 'clubSetup'
